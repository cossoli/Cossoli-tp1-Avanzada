<?php

namespace Codeception\Attribute;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
final class DataProvider
{
}
