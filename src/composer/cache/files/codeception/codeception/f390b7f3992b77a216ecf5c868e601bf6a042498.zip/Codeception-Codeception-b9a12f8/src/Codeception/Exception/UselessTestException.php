<?php

declare(strict_types=1);

namespace Codeception\Exception;

use PHPUnit\Framework\AssertionFailedError;

class UselessTestException extends AssertionFailedError
{
}
